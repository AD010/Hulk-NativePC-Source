param([string]$TexturesArc)
$ErrorActionPreference="Stop"
try {
 Add-Type -AssemblyName System.Windows.Forms
 function Pick([string]$title,[string]$filter) {
  $dlg=New-Object System.Windows.Forms.OpenFileDialog
  $dlg.Title=$title; $dlg.Filter=$filter
  if($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw "Selection cancelled" }
  return $dlg.FileName
 }
 function BE([byte[]]$bytes,[int]$pos) {
  if($pos -lt 0 -or $pos+4 -gt $bytes.Length){throw "Truncated Xbox IND/LFXT"}
  return ([uint64]$bytes[$pos] -shl 24) -bor ([uint64]$bytes[$pos+1] -shl 16) -bor ([uint64]$bytes[$pos+2] -shl 8) -bor [uint64]$bytes[$pos+3]
 }
 if (-not $TexturesArc -or -not (Test-Path -LiteralPath $TexturesArc -PathType Leaf)) {
  $TexturesArc=Pick "Select original Xbox 360 TEXTURES.ARC (not PC)" "Original TEXTURES.ARC|*.arc|All files|*.*"
 }
 $TexturesArc=(Resolve-Path -LiteralPath $TexturesArc).Path
 $Index=Pick "Select Xbox 360 USA index(2).ind (NOT indexXBOX360.ind)" "Xbox indexes|*.ind|All files|*.*"
 $shaExpected="ad22432b3484d079080047a5d6b8a0bffa54b7e8affba1d2273003d9b3c6090d"
 $actual=(Get-FileHash -LiteralPath $Index -Algorithm SHA256).Hash.ToLowerInvariant()
 if($actual -ne $shaExpected){throw "Wrong INDEX.IND region. Required pinned USA index(2).ind, NOT Europe."}
 $index=[IO.File]::ReadAllBytes($Index)
 $blocks=BE $index 0
 if($blocks -ne 52){throw "Unexpected Hulk Xbox USA index structure"}
 $table=-1
 for($g=0;$g -lt 26;$g++){
  $nameOffset=[int](BE $index (4+8*$g))
  $tableOffset=[int](BE $index (8+8*$g))
  if($nameOffset -ge $tableOffset -or $tableOffset -gt $index.Length) { throw "Invalid original index offsets" }
  $group=[Text.Encoding]::ASCII.GetString($index,$nameOffset,$tableOffset-$nameOffset).TrimEnd([char]0)
  if($group -eq "Textures"){$table=$tableOffset;break}
 }
 if($table -lt 0){throw "Original USA INDEX.IND lacks Textures group"}
 $count=[int](BE $index $table)
 if($count -lt 1 -or $count -gt 100000){throw "Invalid Textures records"}
 $hashStart=$table+4
 $recordStart=$hashStart+4*$count
 $targets=@(
  [pscustomobject]@{Name="building_brick41c_grunge_ds";Hash="0006292B";Stream="9B7B5221"},
  [pscustomobject]@{Name="signswap_64x32_eats10_d";Hash="006F533F";Stream="3671D167"},
  [pscustomobject]@{Name="building_empirel_n";Hash="0002F693";Stream="9E095BDC"},
  [pscustomobject]@{Name="frontend_lightmap_dir";Hash="04848026";Stream="80FB0762"},
  [pscustomobject]@{Name="bldg_city_mt0098_egc_marble02b_ds";Hash="00958887";Stream="5F9674B0"},
  [pscustomobject]@{Name="perimeter_sidewalk01_curb_n";Hash="72676FBA";Stream="6EA1F032"},
  [pscustomobject]@{Name="storefront_mid_016d_n";Hash="005445B9";Stream="DEC966BE"},
  [pscustomobject]@{Name="building_windows07a_n";Hash="011B7263";Stream="AA1AA55D"},
  [pscustomobject]@{Name="bf_area1_lightmap_dir";Hash="C01BF23E";Stream="3859B091"},
  [pscustomobject]@{Name="signswap_32x32_misc01_d";Hash="00B81D35";Stream="9C86467C"}
 )
 $map=@{}
 for($i=0;$i -lt $count;$i++){
  $key=('{0:X8}' -f (BE $index ($hashStart+4*$i)))
  $map[$key]=[pscustomobject]@{
   Offset=[int64](BE $index ($recordStart+12*$i))
   Size=[int64](BE $index ($recordStart+12*$i+4))
   Reserved=[int64](BE $index ($recordStart+12*$i+8))
  }
 }
 $data=[IO.File]::OpenRead($TexturesArc)
 $report=New-Object 'System.Collections.Generic.List[string]'
 $report.Add("HULK USA original LFXT headers; source bytes private; version 1")
 $report.Add("USA_INDEX_SHA256="+$actual)
 $report.Add("TEXTURES_ARC_BYTES="+$data.Length)
 $report.Add("This report records real LFXT bytes; it does NOT infer texture type, tiling, mip count or shader fetch slot.")
 try {
  foreach($item in $targets) {
   if(-not $map.ContainsKey($item.Hash)){throw ("USA TEXTURES INDEX has no source texture hash "+$item.Hash)}
   $r=$map[$item.Hash]
   if($r.Reserved -ne 0 -or $r.Offset -lt 4 -or $r.Size -lt 12 -or
      $r.Size -gt 67108864 -or $r.Offset+$r.Size -gt $data.Length){
      throw ("Texture record outside original ARC: "+$item.Name)
   }
   $take=[int][Math]::Min($r.Size,1024)
   $buffer=New-Object byte[] $take
   [void]$data.Seek($r.Offset,[IO.SeekOrigin]::Begin)
   $got=0
   while($got -lt $take){
    $n=$data.Read($buffer,$got,$take-$got)
    if($n -le 0){throw ("Truncated source LFXT: "+$item.Name)}
    $got+=$n
   }
   $magic=[Text.Encoding]::ASCII.GetString($buffer,0,4)
   if($magic -cne "LFXT"){throw ("Source record lacks Xbox LFXT magic: "+$item.Name)}
   $end=4
   while($end -lt [Math]::Min($buffer.Length,133) -and $buffer[$end] -ne 0){$end++}
   if($end -ge [Math]::Min($buffer.Length,133)){throw ("Missing LFXT name: "+$item.Name)}
   $actualName=[Text.Encoding]::ASCII.GetString($buffer,4,$end-4)
   if($actualName -cne $item.Name){throw ("INDEX.IND / ARC texture name mismatch: "+$item.Name+" got "+$actualName)}
   $streamId=[Convert]::ToUInt64($item.Stream,16)
   $positions=@()
   foreach($delta in @(22,34)) {
    $p=$end+1+$delta
    if($p+4 -le $buffer.Length -and (BE $buffer $p) -eq $streamId){$positions+= $delta}
   }
   if($positions.Count -ne 1){throw ("Original LFXT stream link mismatch: "+$item.Name)}
   $report.Add("")
   $report.Add("FILE="+$item.Name+" TEXTURE_HASH="+$item.Hash+" TEXSTREAM_HASH="+$item.Stream)
   $report.Add("INDEX_OFFSET="+$r.Offset+" INDEX_SIZE="+$r.Size+" NAME_NUL_OFFSET="+$end+" STREAM_REF_RELATIVE="+$positions[0])
   $report.Add("CAPTURED_BYTES="+$buffer.Length)
   for($i=0;$i -lt $buffer.Length;$i+=16) {
    $n=[int][Math]::Min(16,$buffer.Length-$i)
    $report.Add(("{0:X4}: " -f $i)+[BitConverter]::ToString($buffer,$i,$n).Replace("-",""))
   }
  }
 } finally {$data.Dispose()}
 $out=Join-Path (Split-Path -Parent $TexturesArc) "Hulk_USA_LFXT_Header_Report.txt"
 [IO.File]::WriteAllLines($out,$report,[Text.Encoding]::UTF8)
 Write-Host "SUCCESS - send ONLY Hulk_USA_LFXT_Header_Report.txt to ChatGPT." -ForegroundColor Green
 Write-Host $out
 Start-Process explorer.exe -ArgumentList ('/select,"'+$out+'"')
} catch {
 Write-Host ("ERROR: "+$_.Exception.Message) -ForegroundColor Red
 exit 1
}
