@echo off
setlocal
title Hulk Xbox 360 USA LFXT Texture Header Collector
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Extract_USA_LFXT_Headers.ps1" "%~1"
echo.
pause
