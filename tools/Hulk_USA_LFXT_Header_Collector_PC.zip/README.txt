THE INCREDIBLE HULK Xbox 360 USA original LFXT texture headers
===========================================================
This tool is only for the 10 TexStreams samples you already supplied.
It collects their corresponding source TEXTURES.ARC descriptor bytes,
which are required to establish actual Xenos GPU formats and mip layouts.

1. Unzip this tiny archive.
2. Drag your ORIGINAL XBOX 360 TEXTURES.ARC onto
   Extract_USA_LFXT_Headers.bat (not the PC TEXTURES.ARC).
3. Select the VERIFIED USA index(2).ind in the file picker.
4. Explorer opens Hulk_USA_LFXT_Header_Report.txt beside TEXTURES.ARC.
5. Send ONLY that TXT to ChatGPT.

All original game archives are read-only. No Python or compiler required.
The code requires the exact pinned USA index SHA256, so you cannot
accidentally pass in the old Europe index or a PC archive.
