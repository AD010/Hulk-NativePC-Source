@echo off
setlocal
title Hulk TexStreams Header Report
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Extract_Hulk_Header_Report.ps1" "%~1"
echo.
pause
