HULK ORIGINAL TEXSTREAMS HEADER REPORT (Windows 10/11)
======================================================
You already extracted and uploaded ten .BIN samples and manifest.txt.
No need to download or unpack TEXSTREA.ARC again.

1. Extract this small ZIP.
2. Double-click "Extract_Hulk_Header_Report.bat".
3. Select the SAME original manifest.txt that is in the folder
   together with the ten .bin files.
4. Wait until Windows Explorer selects
   Hulk_TexStreams_Header_Report.txt
5. Upload ONLY that one text file to the current ChatGPT conversation.

No Python, Visual Studio, or network connection is required.
All source BIN files are read-only. Windows PowerShell 5.1 is sufficient.
The report includes 56-byte candidates and 32-bit fields (BE/LE),
but it does NOT invent Xenos GPU formats, mips, or USA provenance.
