param([string]$Manifest)
$ErrorActionPreference='Stop'
try {
  Add-Type -AssemblyName System.Windows.Forms
  if (-not $Manifest -or -not (Test-Path -LiteralPath $Manifest -PathType Leaf)) {
    $dialog=New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title='Select manifest.txt from previously extracted Hulk TexStreams samples'
    $dialog.Filter='Sample manifest|manifest.txt|Text files|*.txt'
    if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
      throw 'manifest.txt selection cancelled'
    }
    $Manifest=$dialog.FileName
  }
  $Manifest=(Resolve-Path -LiteralPath $Manifest).Path
  if ([IO.Path]::GetFileName($Manifest) -ine 'manifest.txt') {
    throw 'Drag manifest.txt from the SAME folder as the ten original BIN samples'
  }
  $folder=Split-Path -Parent $Manifest
  $lines=Get-Content -LiteralPath $Manifest -Encoding UTF8
  $pattern='^([A-Za-z0-9_-]+) hash=0x([0-9a-fA-F]{8}) offset=([0-9]+) size=([0-9]+)$'
  $srcLength=$null
  $found=0
  $report=New-Object 'System.Collections.Generic.List[string]'
  $report.Add('HULK EoR TexStreams binary record header report v1')
  $report.Add('PROVENANCE: region UNKNOWN; this source manifest does not include pinned USA INDEX SHA256')
  $report.Add('ORIGINAL HEADER FORMAT: UNVERIFIED')
  $report.Add('GPU_FORMAT: UNVERIFIED')
  $report.Add('MIP OFFSETS: UNVERIFIED')
  $report.Add('---')
  foreach($line in $lines) {
    if($line.StartsWith('Source file size: ')) {
      $srcLength=[int64]($line.Split(':')[1].Trim())
    }
    if($line -notmatch $pattern) { continue }
    $name=$Matches[1]
    $hash=$Matches[2].ToUpperInvariant()
    $offset=[int64]::Parse($Matches[3])
    $expected=[int64]::Parse($Matches[4])
    $filename=$name+'_'+$hash+'.bin'
    $path=Join-Path $folder $filename
    if(-not (Test-Path -LiteralPath $path -PathType Leaf)) {
      throw ('Missing original .bin sample: '+$filename)
    }
    $info=Get-Item -LiteralPath $path
    if($info.Length -ne $expected) {
      throw ('Record length differs from manifest: '+$filename)
    }
    if($offset -lt 4 -or $expected -le 0 -or
       ($srcLength -ne $null -and $offset+$expected -gt $srcLength)) {
      throw ('Record range differs from original ARC: '+$filename)
    }
    $max=[int][Math]::Min(160,$info.Length)
    $buffer=New-Object byte[] $max
    $stream=[IO.File]::OpenRead($path)
    try {
      $read=0
      while ($read -lt $max) {
        $n=$stream.Read($buffer,$read,$max-$read)
        if($n -lt 1){ throw ('Truncated sample '+$filename) }
        $read+=$n
      }
    } finally { $stream.Dispose() }
    $report.Add('')
    $report.Add('FILE '+$filename)
    $report.Add('manifest_offset='+$offset+' manifest_size='+$expected)
    $report.Add('bytes_minus_56='+($expected-56)+' aligned_to_4096='+((($expected-56) % 4096) -eq 0))
    $report.Add('sha256='+(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash)
    $take=[int][Math]::Min(56,$buffer.Length)
    $report.Add('offset_0x00_0x37_hex='+[BitConverter]::ToString($buffer,0,$take).Replace('-',''))
    if($buffer.Length -gt 56) {
      $after=[int][Math]::Min(96,$buffer.Length-56)
      $report.Add('offset_0x38_next_hex='+[BitConverter]::ToString($buffer,56,$after).Replace('-',''))
    }
    for($i=0;($i+4) -le [Math]::Min(56,$buffer.Length);$i+=4) {
      $be=([uint64]$buffer[$i] -shl 24) -bor ([uint64]$buffer[$i+1] -shl 16) -bor ([uint64]$buffer[$i+2] -shl 8) -bor ([uint64]$buffer[$i+3])
      $le=([uint64]$buffer[$i+3] -shl 24) -bor ([uint64]$buffer[$i+2] -shl 16) -bor ([uint64]$buffer[$i+1] -shl 8) -bor [uint64]$buffer[$i]
      $report.Add(('offset=0x{0:X2} BE=0x{1:X8} LE=0x{2:X8}' -f $i,$be,$le))
    }
    $found++
  }
  if($found -ne 10) { throw ('Expected all 10 original sample records, got '+$found) }
  if($srcLength -eq $null) { throw 'Missing original TexStreams ARC length in manifest' }
  $report.Insert(4,'SourceARCBytes='+$srcLength)
  $result=Join-Path $folder 'Hulk_TexStreams_Header_Report.txt'
  [IO.File]::WriteAllLines($result,$report,[Text.Encoding]::UTF8)
  Write-Host 'SUCCESS: send ONLY Hulk_TexStreams_Header_Report.txt to ChatGPT' -ForegroundColor Green
  Write-Host $result
  Start-Process explorer.exe -ArgumentList ('/select,"'+$result+'"')
} catch {
  Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red
  exit 1
}
