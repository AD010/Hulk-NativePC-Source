HULK TEXSTREAMS SAMPLE EXTRACTOR - WINDOWS 10/11

1. Unzip the 2 previously supplied parts TEXSTREA.7z.001 and .002
   using 7-Zip. This produces TEXSTREA.ARC.
2. Unzip this small file.
3. Drag TEXSTREA.ARC onto Hulk_TexStreams_Samples.bat.
4. Select your genuine USA index(2).ind in the file picker.
   DO NOT select the older indexXBOX360.ind (Europe).
5. The output Hulk_TexStreams_Samples.zip will appear next to the ARC.
6. Send ONLY that small output ZIP to ChatGPT.

No Python or Visual Studio needed. Original source files are read-only.
