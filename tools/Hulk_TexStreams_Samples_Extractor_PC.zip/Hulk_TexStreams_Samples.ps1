param([string]$Arc)
$ErrorActionPreference="Stop"
try {
 Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.IO.Compression
 function Pick($title,$filter) {
  $d=New-Object System.Windows.Forms.OpenFileDialog
  $d.Title=$title;$d.Filter=$filter
  if($d.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){throw "Selection canceled"}
  return $d.FileName
 }
 function BE($b,$o) {
  if($o -lt 0 -or $o+4 -gt $b.Length){throw "Truncated Xbox index"}
  return (([uint64]$b[$o] -shl 24) -bor ([uint64]$b[$o+1] -shl 16) -bor ([uint64]$b[$o+2] -shl 8) -bor [uint64]$b[$o+3])
 }
 if(-not $Arc -or -not (Test-Path -LiteralPath $Arc -PathType Leaf)){
  $Arc=Pick "Select extracted TEXSTREA.ARC" "Xbox ARC|*.arc|All files|*.*"
 }
 if($Arc -notmatch "(?i)\.arc$"){throw "First unpack TEXSTREA.7z.001 and .002 with 7-Zip. Select TEXSTREA.ARC."}
 $Arc=(Resolve-Path -LiteralPath $Arc).Path
 $Index=Pick "Select USA index(2).ind (NOT indexXBOX360.ind)" "Xbox INDEX|*.ind|All files|*.*"
 $expected="ad22432b3484d079080047a5d6b8a0bffa54b7e8affba1d2273003d9b3c6090d"
 if((Get-FileHash -LiteralPath $Index -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected){
  throw "Wrong index region! Select genuine USA index(2).ind, not the older Europe/Xbox index."
 }
 $bytes=[IO.File]::ReadAllBytes($Index)
 $groups=BE $bytes 0
 if($groups -ne 52){throw "Unexpected USA index structure"}
 $position=-1
 for($g=0;$g -lt 26;$g++){
  $a=BE $bytes (4+8*$g);$b=BE $bytes (8+8*$g)
  if($a -ge $b -or $b -gt $bytes.Length){throw "Invalid index group offsets"}
  $name=[Text.Encoding]::ASCII.GetString($bytes,[int]$a,[int]($b-$a)).TrimEnd([char]0)
  if($name -eq "TexStreams"){$position=[int]$b;break}
 }
 if($position -lt 0){throw "TexStreams group not found"}
 $n=BE $bytes $position
 if($n -lt 1 -or $n -gt 100000){throw "Invalid TexStreams entry count"}
 $hashBase=$position+4;$rowBase=$hashBase+4*$n
 $rows=@()
 for($i=0;$i -lt $n;$i++){
  $id=BE $bytes ($hashBase+4*$i)
  $start=BE $bytes ($rowBase+12*$i)
  $size=BE $bytes ($rowBase+12*$i+4)
  $reserved=BE $bytes ($rowBase+12*$i+8)
  if($reserved -ne 0 -or $start -lt 4 -or $size -lt 1 -or $size -gt 67108864){
   throw "Invalid original TexStreams index record"
  }
  $rows+= [pscustomobject]@{Hash=("{0:X8}" -f $id);Offset=[int64]$start;Size=[int64]$size;I=$i}
 }
 $chosen=@{}
 for($i=0;$i -lt 40;$i++){$chosen[[int][Math]::Floor(($n-1)*$i/39.0)]=$true}
 foreach($r in ($rows | Sort-Object Size -Descending | Select-Object -First 12)){$chosen[$r.I]=$true}
 $out=Join-Path (Split-Path -Parent $Arc) "Hulk_TexStreams_Samples.zip"
 $inputStream=[IO.File]::OpenRead($Arc)
 $outputStream=[IO.File]::Create($out)
 $zip=New-Object System.IO.Compression.ZipArchive($outputStream,[IO.Compression.ZipArchiveMode]::Create,$false)
 try {
  $report=@()
  foreach($id in @($chosen.Keys | Sort-Object {[int]$_})){
   $r=$rows[[int]$id]
   if($r.Offset+$r.Size -gt $inputStream.Length){throw "TexStreams.ARC and USA index do not match"}
   $take=[int][Math]::Min($r.Size,65536)
   $entry=$zip.CreateEntry(("samples/"+$r.Hash+"_head.bin"))
   $stream=$entry.Open()
   try {
    $inputStream.Position=$r.Offset
    $buffer=New-Object byte[] $take
    $done=0
    while($done -lt $take){$count=$inputStream.Read($buffer,$done,$take-$done);if($count -lt 1){throw "Short ARC read"};$done+=$count}
    $stream.Write($buffer,0,$take)
   } finally {$stream.Dispose()}
   $report+= [pscustomobject]@{Hash=$r.Hash;Offset=$r.Offset;Size=$r.Size;SampleBytes=$take}
  }
  $json=[pscustomobject]@{UsaIndexSHA256=$expected;IndexedResources=$n;ArcBytes=$inputStream.Length;Samples=$report} | ConvertTo-Json -Depth 5
  $meta=$zip.CreateEntry("samples_manifest.json")
  $writer=New-Object IO.StreamWriter($meta.Open())
  try {$writer.Write($json)} finally {$writer.Dispose()}
 } finally {$zip.Dispose();$outputStream.Dispose();$inputStream.Dispose()}
 Write-Host "SUCCESS: send this small ZIP to ChatGPT:" -ForegroundColor Green
 Write-Host $out
 Start-Process explorer.exe -ArgumentList ('/select,"'+$out+'"')
} catch {
 Write-Host ("ERROR: "+$_.Exception.Message) -ForegroundColor Red
 exit 1
}
