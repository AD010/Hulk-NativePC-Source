@echo off
title Hulk TexStreams Sample Collector
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Hulk_TexStreams_Samples.ps1" "%~1"
echo.
pause
